# Copyright (c) 2019 10x Genomics, Inc. All rights reserved.

from __future__ import annotations

import csv
import os
from collections import Counter

from six import ensure_binary, ensure_str


class CSVParseException(Exception):
    def __init__(self, msg):
        super().__init__(msg)
        self.msg = msg

    def __str__(self):
        return self.msg


class CSVEmptyException(CSVParseException):
    """The CSV file has no data rows."""


def _iter_file_rows(filename_bytes, filename, descriptive_name):
    """Iterates through non-comment lines in the file, returning them as unicode strings.

    Also skips the BOM if present.

    Raises:
        CSVParseException: The file has no non-comment lines or some lines can't be decoded as ascii.
    """
    with open(filename_bytes, encoding="utf-8-sig", newline=None) as f:
        # encoding utf-8-sig will skip BOM if present.
        has_data = False
        # First non-comment row is treated specially, because it is the header.
        first = True
        for row in f:
            row = row.strip()
            if not row:
                # Skip blank rows.  The csv reader does this anyway, but doing
                # it here saves us the trouble of decoding from ascii.
                continue
            if not row.startswith("#"):
                has_data = True
                if first:
                    # Remove whitespace around column headers
                    row = ",".join(x.strip() for x in row.split(","))
                    first = False
                # Verify is ASCII Compatible
                if not row.isascii():
                    raise CSVParseException(
                        "The {} csv file {} contains non-ascii characters.\n\nRow:\n{}".format(
                            descriptive_name, filename, row
                        )
                    )
                yield row

    if not has_data:
        raise CSVEmptyException(f"The {descriptive_name} csv file {filename} has no data.")


def _validate_columns(reader, descriptive_name, required_cols, valid_cols):
    col_names = reader.fieldnames
    col_set = frozenset(col_names)
    if not col_set.issuperset(set(required_cols)):
        raise CSVParseException(
            """The {} file header does not contain one or more required comma-separated fields: "{}".
The following fields were found: "{}".
Please check that your file is in CSV format and has the required field names.""".format(
                descriptive_name, ", ".join(required_cols), ", ".join(col_names)
            )
        )

    if valid_cols:
        valid_set = frozenset(valid_cols)
        if not col_set.issubset(valid_set):
            extra_columns = sorted(col_set - valid_set)

            msg = """The {} file header contains invalid columns: "{}".
Only the following comma-delimited fields may be used in the file header: "{}".""".format(
                descriptive_name, ", ".join(extra_columns), ", ".join(valid_cols)
            )

            if required_cols:
                msg += """
The following columns are required: "{}".""".format(
                    ", ".join(required_cols)
                )

            msg += """
Please check that you have formatted the {} file correctly and included the appropriate column headers.""".format(
                descriptive_name
            )

            raise CSVParseException(msg)

    if len(col_set) < len(col_names):
        msg = "{} csv has a duplicated column: {}".format(
            descriptive_name,
            ", ".join(sorted(name for name, count in Counter(col_names).items() if count > 1)),
        )
        raise CSVParseException(msg)


def load_csv_filter_comments(filename, descriptive_name, required_cols, valid_cols=None):
    """Returns non-comment lines from the csv files.

    Verifies ASCII encoding and no duplicate columns.

    Args:
        filename (str): The csv file to open.
        descriptive_name (str): The description of the file, to use in error messages.
        required_cols (sequence of str): columns which must be present.
        valid_cols (sequence of str): columns which may be present.  If provided,
            then it is an error for other columns to be present.

    Returns:
        csv.DictReader: The non-comment rows.

    Raises:
        CSVParseException
    """
    filename_bytes = ensure_binary(filename)
    if not os.path.isfile(filename_bytes):
        raise CSVParseException(f"Could not find the {descriptive_name} csv file {filename}")

    if not os.access(filename_bytes, os.R_OK):
        msg = "The {} csv is not readable, please check file permissions: {}".format(
            descriptive_name, filename
        )
        raise CSVParseException(msg)

    reader = csv.DictReader(_iter_file_rows(filename_bytes, filename, descriptive_name))
    _validate_columns(reader, descriptive_name, required_cols, valid_cols)
    return reader


def write_filtered_barcodes(out_csv: os.PathLike, bcs_per_genome: dict[str, list[str]]):
    """Write the barcodes to a CSV.

    Args:
        bcs_per_genome (dict of str to list): Map each genome to its cell-associated barcodes
    """
    with open(out_csv, "w") as f:
        writer = csv.writer(f, lineterminator="\n")
        for genome, bcs in bcs_per_genome.items():
            for bc in bcs:
                writer.writerow([ensure_str(genome), ensure_str(bc)])


def combine_csv(input_csvs, output_csv, header_lines=1):
    """Combine a list of CSV files.

    Files specified in input_csvs are combined into
    a single output csv in output_csv. It is assumed that all
    CSVs have the same header structure. The number of header
    lines is specified in header_lines.
    """
    if not input_csvs:
        output_csv = None
        return
    with open(output_csv, "w") as out:
        for i, icsv in enumerate(input_csvs):
            with open(icsv) as infile:
                header = []
                for _ in range(header_lines):
                    header.append(next(infile))
                if i == 0:
                    for hline in header:
                        out.write(hline)
                for line in infile:
                    out.write(line)
