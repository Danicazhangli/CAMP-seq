#
# Copyright (c) 2021 10X Genomics, Inc. All rights reserved.
#
"""Define the pipeline mode for spatial imaging subpipeline."""


from __future__ import annotations

from enum import Enum
from typing import NamedTuple


class Product(str, Enum):
    VISIUM = "Visium"
    VISIUM_HD = "Visium-HD"
    CYT = "CytAssist"


class SlideType(str, Enum):
    VISIUM = "Visium-Slide"
    XL = "XL-Slide"
    VISIUM_HD = "Visium-HD-Slide"


class PipelineMode(NamedTuple):
    """Pipeline mode used for the spatial imaging subpipeline."""

    product: Product
    slide: SlideType

    def validate(self):
        """Validate the pipeline mode is valid."""
        # TODO: (dongyao) once we finalize the utility of the PipelineMode,
        # add check to prevent illegal product-slide combination

        try:
            _ = Product(self.product)
        except Exception as err:
            raise ValueError(
                f"invalid product '{str(self.product)}' of type {type(self.product)}"
            ) from err

        try:
            _ = SlideType(self.slide)
        except Exception as err:
            raise ValueError(
                f"invalid slide type '{str(self.slide)}' of type {type(self.slide)}"
            ) from err
