#
# Copyright (c) 2020 10X Genomics, Inc. All rights reserved.
#
"""Constants and methods only applicable to spatial targeting."""
SPATIAL_TARGET_DISALLOWED_PANEL_TYPES = ["fully_custom"]
